# Sistema de Niveles - UMNG Visual Novel

## Resumen del Sistema

El juego ahora cuenta con un **sistema de 6 niveles por stat** (Conocimiento, Sociabilidad, Curiosidad), donde cada nivel se obtiene al cumplir ciertos hitos de exploración.

Los **objetos coleccionables** están integrados al sistema y se obtienen como recompensas por alcanzar ciertos niveles.

## Distribución de Niveles por Stage

### **STAGE 0: Entrada a la Universidad** (Niveles 1-2)
**Objetivo**: Introducción y primeras interacciones

| Nivel | Stat | Momento | Condición | Objeto |
|-------|------|---------|-----------|--------|
| 1 | Sociabilidad | Interacción con Carlos | Elegir "¡Gracias!" | - |
| 1 | Curiosidad | Tour con Administrativo | Aceptar recomendaciones | - |
| 2 | Conocimiento | Descubrir Bloque C | Explorar y leer cartel | - |

---

### **STAGE 1: Zonas Verdes** (Niveles 2-4)
**Objetivo**: Exploración básica + Exploración completa + Interacción social

#### Exploración Básica (1 nivel)
| Nivel | Stat | Momento | Condición | Objeto |
|-------|------|---------|-----------|--------|
| 2 | Curiosidad | Explorar más allá del jardín | Elegir "Explorar camino" | - |

#### Interacción con Mickey (2 niveles)
| Nivel | Stat | Momento | Condición | Objeto |
|-------|------|---------|-----------|--------|
| 3 | Curiosidad | Aceptar juego de Mickey | Aceptar jugar | - |
| 2 | Sociabilidad | Responder 2/3 correctas | Fallar 1 respuesta en el juego | - |

#### Exploración Completa (2 niveles)
| Nivel | Stat | Momento | Condición | Objeto |
|-------|------|---------|-----------|--------|
| 3 | Conocimiento | Obtener 3/3 en juego de Mickey | Responder todas correctas | **Pin de Multus** |
| 4 | Curiosidad | Completar el juego (cualquier resultado) | Jugar hasta el final | - |

**Niveles obtenibles en Stage 1:**
- **Curiosidad**: 3 niveles (1→4)
- **Conocimiento**: 1 nivel (2→3)
- **Sociabilidad**: 1 nivel (1→2)

---

### **STAGE 2: Bloque D - Biblioteca** (Niveles 3-5)
**Objetivo**: Exploración de biblioteca y aprendizaje de servicios

#### Exploración Básica (2 niveles)
| Nivel | Stat | Momento | Condición | Objeto |
|-------|------|---------|-----------|--------|
| 5 | Curiosidad | Decidir visitar biblioteca | Elegir "Visitar la biblioteca" | - |
| 3 | Sociabilidad | Tour guiado de biblioteca | Aceptar tour con Zoey | - |
| 4 | Conocimiento | Explorar biblioteca sin tour | Rechazar tour pero explorar solo | - |
| 4 | Conocimiento | Completar tour de biblioteca | Terminar tour completo con Zoey | - |

#### Exploración Completa (1 nivel)
| Nivel | Stat | Momento | Condición | Objeto |
|-------|------|---------|-----------|--------|
| 5 | Conocimiento | Hacer todas las preguntas | Preguntar sobre hemeroteca, servicios físicos y digitales | **Guía de Biblioteca** |

**Niveles obtenibles en Biblioteca:**
- **Conocimiento**: 2 niveles (3→5)
- **Sociabilidad**: 1 nivel (2→3)
- **Curiosidad**: 1 nivel (4→5)

---

### **STAGE 2: Bloque D - Departamento Multimedia** (Niveles 4-6)
**Objetivo**: Conocer estudiantes y al profesor, aprender sobre el programa

#### Interacción con Estudiantes (2 niveles)
| Nivel | Stat | Momento | Condición | Objeto |
|-------|------|---------|-----------|--------|
| 4 | Sociabilidad | Conversar con Sara | Completar pregunta sobre Sara | - |
| 5 | Sociabilidad | Conversar con Daniel | Completar pregunta sobre Daniel | - |

#### Exploración Completa con Profesor (3 niveles finales)
| Nivel | Stat | Momento | Condición | Objeto |
|-------|------|---------|-----------|--------|
| 6 | Conocimiento | Preguntas al Profesor Marcos | Completar 3 preguntas (semilleros, consejos, eventos) | Pin de Multus (si no lo tiene) |
| 6 | Sociabilidad | Preguntas al Profesor Marcos | Completar 3 preguntas (semilleros, consejos, eventos) | - |
| 6 | Curiosidad | Preguntas al Profesor Marcos | Completar 3 preguntas (semilleros, consejos, eventos) | - |

**Niveles obtenibles en Departamento:**
- **Conocimiento**: 1 nivel (5→6)
- **Sociabilidad**: 3 niveles (3→6)
- **Curiosidad**: 1 nivel (5→6)

---

## Tabla Completa de Progresión (6 niveles exactos por stat)

### ✅ Conocimiento (6 niveles)
1. ❌ (no usado)
2. ✅ Descubrir Bloque C (Stage 0)
3. ✅ Pin de Multus - 3/3 respuestas Mickey (Stage 1) + 🎁 **Objeto**
4. ✅ Explorar biblioteca con o sin tour (Stage 2)
5. ✅ Completar preguntas biblioteca + 🎁 **Guía de Biblioteca** (Stage 2)
6. ✅ Completar 3 preguntas del profesor (Stage 2)

### ✅ Sociabilidad (6 niveles)
1. ✅ Agradecer a Carlos (Stage 0)
2. ✅ Responder 2/3 con Mickey (Stage 1)
3. ✅ Tour de biblioteca con Zoey (Stage 2)
4. ✅ Conversar con Sara (Stage 2)
5. ✅ Conversar con Daniel (Stage 2)
6. ✅ Completar 3 preguntas del profesor (Stage 2)

### ✅ Curiosidad (6 niveles)
1. ✅ Aceptar tour del Administrativo (Stage 0)
2. ✅ Explorar más allá del jardín (Stage 1)
3. ✅ Aceptar juego de Mickey (Stage 1)
4. ✅ Completar juego de Mickey (cualquier resultado) (Stage 1)
5. ✅ Visitar biblioteca (Stage 2)
6. ✅ Completar 3 preguntas del profesor (Stage 2)

---

## Sistema de Objetos Coleccionables

### 🎁 Pin del Semillero Multus
**Formas de obtenerlo:**
1. **Primera vez**: Responder 3/3 correctas en el juego de Mickey (Stage 1)
2. **Segunda oportunidad**: Completar 3 preguntas del Profesor Marcos (Stage 2)
   - Si ya lo tienes, recibes un mensaje alternativo

**Recompensa de nivel**: Nivel 3 de Conocimiento

### 📚 Guía Rápida de la Biblioteca
**Forma de obtenerlo:**
- Completar todas las preguntas en la biblioteca (hemeroteca, servicios físicos, servicios digitales)

**Recompensa de nivel**: Nivel 5 de Conocimiento

---

## Reglas del Sistema

1. **Los niveles solo suben, nunca bajan**
   - Las decisiones "negativas" ya no reducen stats
   - Solo se pierde la oportunidad de ganar ese nivel

2. **Sistema de recompensas progresivas**
   - Exploración básica = 1-2 niveles
   - Interacción social = 1 nivel por personaje
   - Exploración completa = nivel final (6)

3. **Niveles mostrados al jugador**
   - Al subir nivel, aparece: "Tu X ha aumentado. Nivel: N/6"
   - El jugador siempre sabe su progreso

4. **Objetos coleccionables integrados**
   - Los objetos se obtienen al alcanzar ciertos niveles clave
   - Pin de Multus: Nivel 3 de Conocimiento
   - Guía de Biblioteca: Nivel 5 de Conocimiento
   - El Pin de Multus tiene 2 oportunidades de obtención (no se duplica)

---

## Rutas Óptimas para Maximizar Stats

### Para maximizar CONOCIMIENTO (6/6):
1. ✅ Descubrir Bloque C
2. ✅ Responder 3/3 en juego de Mickey → **Obtener Pin de Multus**
3. ✅ Explorar biblioteca (con o sin tour)
4. ✅ Completar 3 preguntas en biblioteca → **Obtener Guía de Biblioteca**
5. ✅ Completar 3 preguntas del profesor
**Total: 6/6 niveles + 2 objetos**

### Para maximizar SOCIABILIDAD (6/6):
1. ✅ Agradecer a Carlos
2. ✅ Responder 2/3 con Mickey (fallar intencionalmente 1)
3. ✅ Aceptar tour de biblioteca
4. ✅ Preguntar a Sara sobre su semestre
5. ✅ Preguntar a Daniel sobre su semestre
6. ✅ Completar 3 preguntas del profesor
**Total: 6/6 niveles**

### Para maximizar CURIOSIDAD (6/6):
1. ✅ Aceptar tour del Administrativo
2. ✅ Explorar más allá del jardín
3. ✅ Aceptar juego de Mickey
4. ✅ Completar el juego (cualquier resultado)
5. ✅ Visitar biblioteca
6. ✅ Completar 3 preguntas del profesor
**Total: 6/6 niveles**

### Ruta PERFECTA (18/18 niveles + 2 objetos):
Es posible obtener **todos los niveles y objetos** en una sola partida si:
1. Aceptas todas las interacciones sociales
2. Exploras todos los lugares disponibles
3. Completas todos los mini-juegos y preguntas
4. Interactúas positivamente con todos los personajes

---

## Verificación del Sistema ✅

| Stat | Niveles Requeridos | Niveles Implementados | Estado |
|------|-------------------|----------------------|---------|
| Conocimiento | 6 | 6 | ✅ Completo |
| Sociabilidad | 6 | 6 | ✅ Completo |
| Curiosidad | 6 | 6 | ✅ Completo |
| **TOTAL** | **18** | **18** | ✅ Completo |

### Objetos Coleccionables:
- Pin del Semillero Multus: ✅ Implementado (con prevención de duplicación)
- Guía Rápida de la Biblioteca: ✅ Implementado

---

## Notas de Diseño

- ✅ **Balance perfecto**: Exactamente 6 niveles por stat
- ✅ **Objetos integrados**: Los coleccionables son parte de las recompensas de nivel
- ✅ **Sin duplicación**: El Pin de Multus no se puede obtener 2 veces
- ✅ **Progresión Natural**: Los niveles se alinean con la narrativa del descubrimiento
- ✅ **Sin penalización**: Las decisiones "malas" solo impiden ganar niveles, no los reducen
- ✅ **Claridad total**: El jugador siempre ve su progreso (X/6)
- ✅ **Flexibilidad**: Múltiples caminos para alcanzar niveles altos
- ✅ **Recompensas tangibles**: Los objetos se vinculan a logros específicos

---

**Fecha de implementación**: 17 de Noviembre de 2025  
**Versión del sistema**: 2.0 (Revisión completa)  
**Estado**: ✅ Sistema completo y balanceado
